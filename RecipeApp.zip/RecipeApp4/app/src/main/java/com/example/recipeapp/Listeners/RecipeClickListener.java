package com.example.recipeapp.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
