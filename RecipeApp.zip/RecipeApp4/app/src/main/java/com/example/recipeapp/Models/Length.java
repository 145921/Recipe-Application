package com.example.recipeapp.Models;

public class Length {
    public int number;
    public String unit;
}
