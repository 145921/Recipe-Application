package com.example.recipeapp.Models;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;
}
